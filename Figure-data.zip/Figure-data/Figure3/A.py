import numpy as np
import matplotlib.pyplot as plt


plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['legend.fontsize'] = 8

# constant
Z = 1
epsilon_r = 78.5
epsilon_0 = 8.854e-12
k_B = 1.380649e-23
T = 298
e = 1.602e-19

fig, ax = plt.subplots(figsize=(4, 3), dpi=300)

# R
R_nm = 125
R = R_nm * 1e-9  # m

# 离子浓度列表（mol/L）
rho_bulk_list = [1e-3, 1e-5, 1e-7]
colors = ['#1f77b4', '#2ca02c', '#ff7f0e', '#d62728'] 
colors = ['#8daac4', '#cb918a', '#66a06f',  '#a07373']

# （e/nm²）
target_sigmas = [0.015, 0.002, 0.0007]
target_colors = ['gray']*3
target_labels = [r'$\sigma_0=0.015$', r'$\sigma_0=0.002$', r'$\sigma_0=0.0007$']

for i, rho_mol_L in enumerate(rho_bulk_list):
    rho_bulk = rho_mol_L * 6.022e23 * 1000  # ions/m³
    psi0 = np.linspace(1e-3, 0.23, 400)

    term1 = 2 * np.sinh(e * psi0 / (2 * k_B * T))
    tmp = 1 / np.sqrt(epsilon_0 * epsilon_r * k_B * T / (2 * e**2 * Z**2 * rho_bulk))
    term2 = (4 / R) * np.tanh(e * psi0 / (4 * k_B * T)) / tmp
    factor = Z * np.sqrt(2 * epsilon_r * epsilon_0 * k_B * T * rho_bulk)
    sigma0_C_per_m2 = factor * (term1 + term2)
    sigma0_e_per_nm2 = sigma0_C_per_m2 / e / 1e18

    ax.plot(sigma0_e_per_nm2, psi0*-1000, label=f"{rho_mol_L*1000:.4f} mM/L",
        lw=1.5, color=colors[i])



for i, sigma in enumerate(target_sigmas):
    ax.axvline(x=sigma, linestyle='--', color=target_colors[i], lw=1)
    ax.text(sigma*1.05, -150, target_labels[i], rotation=90,
            va='top', ha='left', fontsize=8, color='gray')


ax.set_xscale("log")
ax.set_xlabel(r"Surface charge density $\sigma_0$ (e$^-$/nm$^2$)")
ax.set_ylabel(r"Surface potential (mV)")
#ax.set_title(f"$\sigma_0$ vs $\psi_0$ at R = {R_nm} nm")
ax.legend(frameon=False,loc='upper right')
#ax.grid(True, which="both", linestyle="--", linewidth=0.4, alpha=0.5)
#plt.ylim(0,230)
plt.tight_layout()
plt.show()

